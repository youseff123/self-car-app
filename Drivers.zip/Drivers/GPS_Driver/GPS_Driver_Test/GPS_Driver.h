

void GPS_init();
void Get_GPS_Location(float *Location_long , float *Location_lat) ;