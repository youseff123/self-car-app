

// GPS Pins
#define GPS_RXPin 5
#define GPS_TXPin 4