
#define SOUND_SPEED 0.034

void Ultrasonic_init();
float get_ultrasonic_Front_reading();
float get_ultrasonic_Back_reading();