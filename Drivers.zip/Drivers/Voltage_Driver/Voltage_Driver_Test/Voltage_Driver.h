
#ifndef VOLTAGE_H
#define VOLTAGE_H


float Get_Battary_voltage();

#endif //VOLTAGE_H
