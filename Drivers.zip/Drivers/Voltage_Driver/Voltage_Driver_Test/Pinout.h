
// Voltage_Sensor

#define VOLTAGR_SENSOR_PIN A0