// Pinout defenitions


#define Motor_Driver_Right_PWM D4 // D4 PWM Left wheel ENA
#define Motor_Driver_Left_PWM D5  // D5 pwm Right wheel ENB


// Motor R F
#define Motor_Driver_Right_Dir_in1  D0 // d0 in2
#define Motor_Driver_Right_Dir_in2  D1 // d1  in1

// Motor R B
#define Motor_Driver_Left_Dir_in3   D2 // d2  in3
#define Motor_Driver_Left_Dir_in4   D3 // d3  in4


